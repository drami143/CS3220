package hw3.controller;


import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import hw3.model.ListOfGroups;
import hw3.model.ListOfStudents;

@WebServlet("/ShowEmployee")
public class Service extends HttpServlet {

    private static final long serialVersionUID = 1L;

    protected void doGet( HttpServletRequest request,
        HttpServletResponse response ) throws ServletException, IOException
    {
        request.getRequestDispatcher( "/WEB-INF/EmployeeForm.jsp" )
            .forward( request, response );
    }

    protected void doPost( HttpServletRequest request,
        HttpServletResponse response ) throws ServletException, IOException
    {
        List<ListOfStudents> employees = new ArrayList<ListOfStudents>();

        String sql = "select * from students";

        Connection c = null;
        try
        {
            String url = "jdbc:mysql://cs3.calstatela.edu/cs3220stu63";
            Statement stmt = c.createStatement();
            ResultSet rs = stmt.executeQuery( sql );
            while( rs.next() )
            {
            	ListOfStudents employee = new ListOfStudents();
                employee.setId( rs.getInt( "id" ) );
                employee.setName( rs.getString( "name" ) );
                employee.setAge( rs.getInt( "age" ) );
                employee.setParent( rs.getString( "parent" ) );
                employee.setEmail( rs.getString( "email" ) );
                employee.setGroup( rs.getString( "g" ) );
                employees.add( employee );
            }
        }
        catch( SQLException e )
        {
            throw new ServletException( e );
        }
        finally
        {
            try
            {
                if( c != null ) c.close();
            }
            catch( SQLException e )
            {
                throw new ServletException( e );
            }
        }

        request.setAttribute( "employees", employees );
        request.getRequestDispatcher( "/WEB-INF/EmployeeInfo.jsp" )
            .forward( request, response );
    }
}