package hw3.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import hw3.model.ListOfStudents;

@WebServlet("/EditStudent")
public class EditStudent extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public EditStudent() {
        super();
    }
    
    @SuppressWarnings("unchecked")
    private ListOfStudents getStu(int id){
        List<ListOfStudents> students = (List<ListOfStudents>) getServletContext().getAttribute("students");
        for(ListOfStudents student : students)
            if(student.getId() == id ) return student;
        return null;
    }
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String id = request.getParameter("id");
        ListOfStudents students = getStu(Integer.parseInt(id));
        request.setAttribute("students", students);
        request.getRequestDispatcher("EditStudent.jsp").forward(request, response);
	}

	    protected void doPost( HttpServletRequest request,
	        HttpServletResponse response ) throws ServletException, IOException
	    {
	        ListOfStudents students = getStu(Integer.parseInt(request.getParameter("id")));
	        students.setName(request.getParameter("name"));
	        students.setAge(2022 - Integer.parseInt(request.getParameter("age")));
	        students.setParent(request.getParameter("parent"));
	        students.setEmail(request.getParameter("email"));
	        students.setGroup(request.getParameter("group"));

	        request.getRequestDispatcher("Students.jsp").forward(request, response);
	    }

}
