package hw3.controller;

import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import hw3.model.ListOfStudents;

@WebServlet("/NewStudent")
public class NewStudent extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public NewStudent() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	       
		request.getRequestDispatcher("NewStudent.jsp").forward(request, response);
	    }

	    @SuppressWarnings("unchecked")
	    protected void doPost( HttpServletRequest request,
	        HttpServletResponse response ) throws ServletException, IOException
	    {
	        List<ListOfStudents> students = (List<ListOfStudents>)getServletContext().getAttribute("students");

	        String name = request.getParameter("name");
	        int age = 2022 - Integer.parseInt(request.getParameter("age"));
	        String pName = request.getParameter("pName");
	        String pEmail = request.getParameter("pEmail");   
	        String group = request.getParameter("group");

	        students.add(new ListOfStudents());

	        request.getRequestDispatcher("Students.jsp").forward(request, response);
	    }

}

