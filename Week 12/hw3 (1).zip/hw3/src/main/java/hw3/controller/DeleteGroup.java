package hw3.controller;

import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import hw3.model.ListOfGroups;

@WebServlet("/DeleteGroup")
public class DeleteGroup extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public DeleteGroup() {
        super();
    }

    @SuppressWarnings("unchecked")
    protected void doGet( HttpServletRequest request,
        HttpServletResponse response ) throws ServletException, IOException
    {
        int id = Integer.parseInt( request.getParameter("id"));

        ListOfGroups g = null;
        List<ListOfGroups> group = (List<ListOfGroups>) getServletContext()
            .getAttribute("groups");
        
        for(ListOfGroups groups : group)
            if(groups.getId() == id ){
                g = groups;
                break;
            }

        if(g != null)group.remove(g);
        request.getRequestDispatcher("Groups.jsp").forward(request, response);
    }
}
