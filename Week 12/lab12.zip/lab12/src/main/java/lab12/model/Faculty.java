package lab12.model;

public class Faculty {

	private int id;
	
    private String name;

    private boolean isChair;

    public Faculty()
    {
        isChair = false;
    }

    public Faculty( String name )
    {
        this();
        this.name = name;
    }
    
    public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

    public String getName()
    {
        return name;
    }

    public void setName( String name )
    {
        this.name = name;
    }

    public boolean isChair()
    {
        return isChair;
    }

    public void setChair( boolean isChair )
    {
        this.isChair = isChair;
    }

}