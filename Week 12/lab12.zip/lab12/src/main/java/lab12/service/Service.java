package lab12.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import lab12.model.Faculty;

public class Service {

    private String url = "jdbc:mysql://cs3.calstatela.edu/cs3220stu63";

    private String username = "cs3220stu63";

    private String password = "JVEATawn91Xg";

    private Connection connection;

    public Service()
    {
        try
        {
            connection = DriverManager.getConnection( url, username, password );
        }
        catch( SQLException e )
        {
            e.printStackTrace();
        }
    }

    public void close()
    {
        if( connection != null )
        {
            try
            {
                connection.close();
            }
            catch( SQLException e )
            {
                e.printStackTrace();
            }
        }
    }

    public List<Faculty> getEntries()
    {
        List<Faculty> entries = new ArrayList<Faculty>();

        try
        {
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery( "select * from faculty" );
            while( rs.next() )
            {
            	Faculty entry = new Faculty();
                entry.setId( rs.getInt( "id" ) );
                entry.setName( rs.getString( "name" ) );
                entry.setChair( rs.getBoolean( "isChair" ) );
                entries.add( entry );
            }
            stmt.close();
        }
        catch( SQLException e )
        {
            e.printStackTrace();
        }

        return entries;
    }

    public Faculty getEntry( int id )
    {
    	Faculty entry = new Faculty();
        try
        {
            String sql = "select * from faculty where id = ?";
            PreparedStatement pstmt = connection.prepareStatement( sql );
            pstmt.setInt( 1, id );
            ResultSet rs = pstmt.executeQuery();
            if( rs.next() )
            {
                entry.setId( rs.getInt( "id" ) );
                entry.setName( rs.getString( "name" ) );
                entry.setChair( rs.getBoolean( "isChair" ) );
            }
            pstmt.close();
        }
        catch( SQLException e )
        {
            e.printStackTrace();
        }
        return entry;
    }

    public int addEntry( String name, String message )
    {
        int id = 0;
        try
        {
            String sql = "insert into faculty (name, isChair) values (?, ?)";
            PreparedStatement pstmt = connection.prepareStatement( sql,
                Statement.RETURN_GENERATED_KEYS );
            pstmt.setString( 1, name );
            pstmt.setString( 2, message );
            pstmt.executeUpdate();
            ResultSet rs = pstmt.getGeneratedKeys();
            if( rs.next() ) id = rs.getInt( 1 );
            pstmt.close();
        }
        catch( SQLException e )
        {
            e.printStackTrace();
        }
        return id;
    }

    public void updateEntry( int id, String name, boolean isChair )
    {
        try
        {
            String sql = "update faculty set name = ?, chair = ? where id = ?";
            PreparedStatement pstmt = connection.prepareStatement( sql );
            pstmt.setString( 1, name );
            pstmt.setBoolean( 2, isChair );
            pstmt.setInt( 3, id );
            pstmt.executeUpdate();
            pstmt.close();
        }
        catch( SQLException e )
        {
            e.printStackTrace();
        }
    }

    public void deleteEntry( int id )
    {
        try
        {
            String sql = "delete from faculty where id = ?";
            PreparedStatement pstmt = connection.prepareStatement( sql );
            pstmt.setInt( 1, id );
            pstmt.executeUpdate();
            pstmt.close();
        }
        catch( SQLException e )
        {
            e.printStackTrace();
        }
    }
}
