package hw1;


import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/NewGroup")
public class NewGroup extends HttpServlet {

    private static final long serialVersionUID = 1L;

    public NewGroup()
    {
        super();
    }

    protected void doGet( HttpServletRequest request,
        HttpServletResponse response ) throws ServletException, IOException
    {
  
        response.setContentType( "text/html" );
        PrintWriter pw = response.getWriter();
        pw.println("<html><head><title>New Group</title></head><body>");
        
        pw.println("<form action='NewGroup' method='post'>");
        
        pw.println("<table border ='1'>");
        pw.println("<tr><th>" + "Name" + "</th>" + "<td>" + " <input type='text' name='name'>" + "</td></tr>");
        
        pw.println("<tr>");
        pw.println("<td>" + "<input type='submit' name='Add' value='Add'>" + "</td>");
        pw.println("</tr>");
        pw.println("</form>");
        pw.println("</body></html>");
    }

    @SuppressWarnings("unchecked")
    protected void doPost( HttpServletRequest request,
        HttpServletResponse response ) throws ServletException, IOException
    {
        String name = request.getParameter("name");
        String add = request.getParameter("Add");
        ListOfGroups entry = new ListOfGroups(name, add);

        List<ListOfGroups> groups = (List<ListOfGroups>)getServletContext().getAttribute("groups");
        groups.add(entry);

        response.sendRedirect("NewStudent");
    }

}