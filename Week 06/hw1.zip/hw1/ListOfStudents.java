package hw1;

public class ListOfStudents {
static int idSeed = 1;

private int id;

private String name;
private String age;
private String parent;
private String email;
private String add;

public ListOfStudents(String name, String age, String parent, String email) {
	
	this.id = idSeed++;
	this.name = name;
	this.age = age;
	this.parent = parent;
	this.email = email;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getAge() {
	return age;
}
public void setAge(String age) {
	this.age = age;
}
public String getParent() {
	return parent;
}
public void setParent(String parent) {
	this.parent = parent;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getAdd() {
	return email;
}
public void setAdd(String email) {
	this.email = email;
}

}

