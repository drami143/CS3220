package hw1;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(urlPatterns = "/Students", loadOnStartup = 1)
public class Students extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public Students() {
        super();
        // TODO Auto-generated constructor stub
    }

	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		
		List<ListOfStudents> students = new ArrayList<ListOfStudents>();
		
		students.add(new ListOfStudents("Student", "Age", "Parent", "Email"));
		students.add(new ListOfStudents("Lorena", "6", "Maria", "mari124@gmail.com"));
		students.add(new ListOfStudents("Elizabeth", "4", "Josue", "2376Josu@gmail.com"));
		students.add(new ListOfStudents("Bryan", "8", "Anthony" ,"antman54@gmail.com"));
		students.add(new ListOfStudents("Raul", "10", "Julia" ,"julie82@gmail.com"));
		
		getServletContext().setAttribute("students", students);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		@SuppressWarnings("unchecked")
		List<ListOfStudents> students = (List<ListOfStudents>)getServletContext().getAttribute("students");
		
		response.setContentType ("text/html");
		PrintWriter pw = response.getWriter();
		pw.println ("<html><head><title> List of Students </title></head><body>");
		pw.println ("<p><a href=NewStudent>New Student</a><br>");
		
		pw.println("<h2></h2>");
		pw.println("<table border ='1'>");
		
		for(ListOfStudents list : students) {
			
			pw.println("<tr>");
			pw.println("<td>" + list.getName() + "&nbsp" + "</td>");
			pw.println("<td>" + list.getAge() + "&nbsp" + "</td>");
			pw.println("<td>" + list.getParent() + "&nbsp" + "</td>");
			pw.println("<td>" + list.getEmail() + "&nbsp" + "</td>");
			pw.println("</tr>");
			
			
		}
		pw.println("</table>");
		pw.println("</body></html>");
	}
}











