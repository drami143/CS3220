package hw1;

public class ListOfGroups {

	static int idSeed = 1;

	private int id;
	
	private String group;
	private String members;

	public ListOfGroups(String group, String members) {
		
		this.id = idSeed++;
		this.group = group;
		this.members = members;

	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getGroup() {
		return group;
	}
	public void setGroup(String group) {
		this.group = group;
	}
	public String getMembers() {
		return members;
	}
	public void setMembers(String members) {
		this.members = members;
	}

	}


