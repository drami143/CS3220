package hw1;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class NewStudent
 */
@WebServlet("/NewStudent")
public class NewStudent extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public NewStudent() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	       
		response.setContentType( "text/html" );
	        
		PrintWriter pw = response.getWriter();
	       
		pw.println("<html><head><title>New Student</title></head><body>");
	        
	    pw.println("<form action='NewStudent' method='post'>");
	        
	    pw.println("<table border ='1'>");
	    pw.println("<tr><th>" + "Name" + "</th>" + "<td>" + " <input type='text' name='name'>" + "</td></tr>");
	    pw.println("<tr><th>" + "Age" + "</th>" + "<td>" + " <input type='text' name='age'>" + "</td></tr>");
	    pw.println("<tr><th>" + "Parent Name" + "</th>" + "<td>" + " <input type='text' name='pName'>" + "</td></tr>");
	    pw.println("<tr><th>" + "Parent Email" + "</th>" + "<td>" + " <input type='text' name='pEmail'>" + "</td></tr>");
	    pw.println("<tr><th>" + "Group" + "</th>" + "<td>" + " <input type='droplist' name='group'>" + "</td></tr>");
	    pw.println("<tr>");
	    pw.println("<td>" + "<input type='submit' name='Add&nbsp&nbsp' value='add'>" + "</td>");
	    pw.println("</tr>");
	    pw.println("</form>");
	    pw.println("</body></html>");
	    }

	    @SuppressWarnings("unchecked")
	    protected void doPost( HttpServletRequest request,
	        HttpServletResponse response ) throws ServletException, IOException
	    {
	        String name = request.getParameter("name");
	        String age = request.getParameter("age");
	        String pName = request.getParameter("pName");
	        String pEmail = request.getParameter("pEmail");
	        String group = request.getParameter("group");
	        String add = request.getParameter("add");
	        ListOfStudents entry = new ListOfStudents(name,age, pName, pEmail);

	        List<ListOfStudents> student = (List<ListOfStudents>)getServletContext().getAttribute("students");
	        student.add(entry);

	        response.sendRedirect("Students");
	    }

}
