package cs3220.model;

public class Request {

	static int idSeed = 1;
	private int id;
	private String time;
	private String name;
	private String type;
	private String stat;


	
	 public Request( String time, String name, String type, String stat ) {
		 	super();
		 	
	        this.id = idSeed++;
	        this.time = time;
	        this.name = name;
	        this.type = type;
	        this.stat = stat;
	    }
	 
	 
	public Request() {
		super();
		id = idSeed++;
		
	}


	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTime() {
		 return time;

		 }

	public void setTime(String time) {
		this.time = time;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getStat() {
		return stat;
	}

	public void setStat(String stat) {
		this.stat = stat;
	}
}

