package cs3220.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import cs3220.model.Request;

/**
 * Servlet implementation class ListOfRequests
 */
@WebServlet("/ListOfRequests")
public class ListOfRequests extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public ListOfRequests() {
        super();
    }

	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		  
		List<Request> reqs = new ArrayList<Request>();
		
		Request r1 = new Request();
		r1.setTime("Request Time");
		r1.setName("Requested By");
		r1.setType("Service Type");
		r1.setStat("Status");
		
		Request r2 = new Request();
		r2.setTime("2013-02-14 8:15:33AM");
		r2.setName("John");
		r2.setType("Phone");
		r2.setStat("Open");
		
		Request r3 = new Request();
		r3.setTime("2013-02-18 2:11:12PM");
		r3.setName("Jane");
		r3.setType("Computer");
		r3.setStat("Assigned");
		
		Request r4 = new Request();
		r4.setTime("2013-01-12 3:15:16PM");
		r4.setName("Jack");
		r4.setType("Account");
		r4.setStat("Completed");
		
		reqs.add(r1);
		reqs.add(r2);
		reqs.add(r3);
		reqs.add(r4);
		getServletContext().setAttribute("request", reqs);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.getRequestDispatcher("/WEB-INF/ListRequest.jsp").forward(request, response);
	}

}

