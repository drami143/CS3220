package hw2.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import hw2.model.ListOfGroups;
import hw2.model.ListOfStudents;

@WebServlet("/EditGroups")
public class EditGroups extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public EditGroups() {
        super();
    }
    
    @SuppressWarnings("unchecked")
    private ListOfGroups getG(int id){
        List<ListOfGroups> g = (List<ListOfGroups>) getServletContext().getAttribute("groups");
        for(ListOfGroups group : g)
            if(group.getId() == id ) return group;
        return null;
    }
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String id = request.getParameter("id");
	    ListOfGroups g = getG(Integer.parseInt(id));
	    request.setAttribute("groups", g);
	    request.getRequestDispatcher("/WEB-INF/EditGroups.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		ListOfGroups groups = getG(Integer.parseInt(request.getParameter("id")));
		groups.setGroup(request.getParameter("groups"));
		groups.setMembers(request.getParameter("members"));

	        request.getRequestDispatcher("/WEB-INF/Groups.jsp").forward(request, response);
	}
}