package hw2.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import hw2.model.ListOfGroups;

@WebServlet("/Groups")
public class Groups extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public Groups() {
		super();
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<ListOfGroups> g = new ArrayList<ListOfGroups>();
		g.add(new ListOfGroups("Minnows","John"));
		g.add(new ListOfGroups("Minnows","Luke"));
    	g.add(new ListOfGroups("Dolphines", "Jane"));
    	g.add(new ListOfGroups("", "Tina"));
    	getServletContext().setAttribute("groups", g);
		
		request.getRequestDispatcher("/WEB-INF/Groups.jsp").forward(request, response);
	}
	protected void doPost( HttpServletRequest request,
        HttpServletResponse response ) throws ServletException, IOException{
    	doGet(request, response);
    }

}

