package hw2.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import hw2.model.ListOfStudents;

@WebServlet(urlPatterns = "/Students", loadOnStartup = 1)
public class Students extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<ListOfStudents> student = new ArrayList<ListOfStudents>();
		student.add(new ListOfStudents("John", 4, "Sue", "sue@gmail.com", "Minnows"));
    	student.add(new ListOfStudents("Jane", 9, "Sue", "sue@gmail.com", "Dolphines"));
    	student.add(new ListOfStudents("Luke", 4, "Josue", "steve@gmail.com", "Minnows"));
    	student.add(new ListOfStudents("Tina", 7, "Paula" ,"paula@gmail.com", ""));

    	
    	getServletContext().setAttribute("students", student);
		request.getRequestDispatcher("/WEB-INF/Students.jsp").forward(request, response);
				
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}